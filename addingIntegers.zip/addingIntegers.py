first = 23
second = 7
sum = first + second

print (sum)