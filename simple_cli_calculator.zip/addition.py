first = int(input("Enter initial integer: "))
second = int(input("Enter last integer: "))
sum = first + second

print ("The addition is " + str(sum))