num1 = int(input("Enter the larger value: "))
num2 = int(input("Enter the divisor: "))
division = num1 / num2

print ("The division result is: " + str(division))