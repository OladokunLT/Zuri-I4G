val1 = int(input("enter first value: "))
val2 = int(input("enter last value: "))

print("Your value1 is " + str(val1))
print("Your value2 is " + str(val2))

multiply = val1 * val2
print("The multiplication is " + str(multiply))