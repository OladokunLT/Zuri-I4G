firstInput = int(input("enter larger value: "))
secondInput = int(input("enter smaller value: "))

print("Your first value is " + str(firstInput))
print("Your second value is " + str(secondInput))

subtract = firstInput - secondInput
print("The subtraction is " + str(subtract))
